﻿using UnityEngine;

public class PlayerJumpState : PlayerBaseState
{
    public PlayerJumpState(PlayerStateMachine stateMachine, PlayerStateFactory playerStateFactory)
        : base(stateMachine, playerStateFactory) { }

    public override void CheckSwitchStates()
    {
        SwitchState(Factory.Idle());
    }

    public override void EnterState()
    {
        HandleJump();
    }

    public override void ExitState()
    {

    }

    public override void InitializeSubState()
    {

    }

    public override void UpdateState()
    {
        CheckSwitchStates();
    }

    void HandleJump()
    {
        // Jump Logic
    }
}