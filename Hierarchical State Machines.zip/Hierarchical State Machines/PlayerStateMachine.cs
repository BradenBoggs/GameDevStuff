using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerStateMachine : MonoBehaviour
{
    PlayerStateFactory states;
    PlayerBaseState currentState;

    CharacterController characterController;
    Animator animator;
    PlayerInput playerInput;

    Vector2 currentMovementInput;
    Vector2 appliedMovement;

    bool isMovementPressed;
    bool isRunPressed;
    bool isJumpPressed;

    // getters and setters
    public PlayerBaseState CurrentState { get { return currentState; } set { currentState = value; } }
    public bool IsJumpPressed { get { return isJumpPressed; } }
    public bool IsMovementPressed { get { return isMovementPressed; } }
    public bool IsRunPressed { get { return isRunPressed; } }

    private void Awake()
    {
        states = new PlayerStateFactory(this);
        currentState = states.Grounded();
        currentState.EnterState();

        playerInput = new PlayerInput();
        characterController = GetComponent<CharacterController>();
        animator = GetComponent<Animator>();

        playerInput.Player.Movement.started += OnMovementInput;
        playerInput.Player.Movement.canceled += OnMovementInput;
        playerInput.Player.Movement.performed += OnMovementInput;
        playerInput.Player.Sprint.started += OnRun;
        playerInput.Player.Sprint.canceled += OnRun;
        playerInput.Player.Jump.started += OnJump;
        playerInput.Player.Jump.started += OnJump;

    }

    protected void Update()
    {
        currentState.UpdateStates();

        characterController.Move(appliedMovement * Time.deltaTime);
    }

    private void OnEnable()
    {
        playerInput.Player.Enable();
    }

    private void OnDisable()
    {
        playerInput.Player.Disable();
    }

    void OnMovementInput(InputAction.CallbackContext context)
    {
        currentMovementInput = context.ReadValue<Vector2>();
        isMovementPressed = context.performed;
    }

    void OnJump(InputAction.CallbackContext context)
    {
        isJumpPressed = context.ReadValueAsButton();
    }

    void OnRun(InputAction.CallbackContext context)
    {
        isRunPressed = context.ReadValueAsButton();
    }

    protected void OnGUI()
    {
        string content = currentState != null ? currentState.ToString() : "(No Current State)";

        content = "Root State: " + CurrentState.ToString();
        GUILayout.Label($"<color='black'><size=40>{content}</size></color>");
    }

}
